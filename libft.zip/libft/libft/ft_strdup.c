/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmazibu <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 11:18:05 by lmazibu           #+#    #+#             */
/*   Updated: 2018/05/23 12:04:58 by lmazibu          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

char *ft_strdup(char * src)
{
	char *s;
	int len;
	while (src [len])
		++i;
	if(!(s=(char*)malloc(size of (char) (len +1))))
		return(NULL);
	s[len] = ('0');
	while(len-->-1)
		s[len]= src [len];
	return(s);
}
